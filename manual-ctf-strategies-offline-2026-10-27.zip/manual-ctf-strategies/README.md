# Manual CTF Strategies offline toolkit

Open [index.html](index.html) in a browser. Instructions, search, worksheets and
bundled synthetic inputs work offline. External technical references need internet.
Read [TOOLKIT.html](TOOLKIT.html) for commands, limits and approved manual alternatives;
[RULES.html](RULES.html) summarizes competition restrictions.
[Core workflows](CORE_WORKFLOWS.md) prioritize the 32 Trend Micro proposals;
[specialist workflows](SPECIALIST_WORKFLOWS.html) cover the other prepared task routes.
[Practice inputs](CORE_PRACTICE.html) and the [Hashcat cheatsheet](HASHCAT.md) are available offline; [Python templates](TEMPLATES.html)
include file preview, JWT inspection, binary parsing, HTTP experiments and optional pwntools clients.
[Python requirements](requirements.txt) and [reviewed dependency pins](constraints.txt)
list the optional, non-AI packages for Linux/WSL CPython 3.11/3.12.

From this folder, in Linux or WSL with CPython 3.10 or newer:

```sh
python3 --version
python3 scripts/ctf.py doctor --workflow bytes
python3 scripts/ctf.py bits --text '01000001' --json
python3 -m unittest discover -s tests -p 'test_toolkit*.py'
python3 scripts/autosolve.py --help
```

`autosolve.py` supports bounded local encoding, declared AES/RSA checks,
ZIP/MIME/PDF extraction, PNG trailing containers, image metadata/views, and an
explicit-origin chatbot profile with selected plans. `ai_model.py` inspects
offline model metadata and checks explicit wrapper parity. Chatbot runs keep
private reports and resume records; offline model reports are private.
Its reports mark remaining planned families as not implemented; a candidate
is not a validated challenge answer.

Use paths understood by that interpreter; quote paths containing spaces.
Native Windows Python is unsupported. The byte workflows use only the standard
library. Full inspection also needs approved `file` and ExifTool installations;
`doctor --workflow inspect` reports readiness without installing anything.

Locally tested on CPython 3.11.11 and 3.12.3 in Ubuntu/WSL. Python 3.10, Kali and organiser
machines remain unverified. This export is a local snapshot; it does not update
the hosted guide.
This folder contains authored content only; private evidence and organiser
source documents are excluded. Prewritten helpers are not new approved tools.
